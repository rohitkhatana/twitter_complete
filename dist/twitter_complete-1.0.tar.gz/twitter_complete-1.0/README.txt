Twitter_complete is python module for interacting with the twitter apis.
It is revised with latest twitter api versio 1.1
